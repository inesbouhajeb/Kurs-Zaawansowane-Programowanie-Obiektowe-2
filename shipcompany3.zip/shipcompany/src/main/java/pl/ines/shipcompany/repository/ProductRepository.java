package pl.ines.shipcompany.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import pl.ines.shipcompany.model.Product;

import java.util.List;

/*
* Klasa podobna do DAO działa jak zbiór, pozwala na dostep do bazy danych porpzez dodatkowa abstrakcje.
* */
//pierwszy arg to typ encji ktora bedziemy chcieli zapisywac
//drugi arg to typ klucza czyli id
@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

    @Query("select p from Product p where p.thickness=:thickness")
    List<Product> getProductsWhereThicknessIs(@Param("thickness") int thickness,@Param("thickness") int width,@Param("thickness") int length,@Param("thickness") int quantity);

    @Query("select p from Product p order by p.thickness")
    List <Product> orderByThickness();

    @Query("select p from Product p order by p.width")
    List <Product> orderByWidth();

    @Query("select p from Product p order by p.length")
    List <Product> orderByLength();

    @Query("select p from Product p order by p.quantity")
    List <Product> orderByQuantity();

    @Query("select p from Product p order by p.grade")
    List <Product> orderByGrade();

    @Query("select p from Product p order by p.tolerance")
    List <Product> orderByTolerance();

}
