package pl.ines.shipcompany;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShipcompanyApplication {

    public static void main(String[] args) {

        SpringApplication.run(ShipcompanyApplication.class, args);
    }
}
