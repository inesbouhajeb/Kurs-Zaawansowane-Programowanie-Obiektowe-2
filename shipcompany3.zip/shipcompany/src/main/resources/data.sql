insert into product(thickness,width,length,quantity,grade,tolerance) values
(9, 3000,9350,2,'A','0/+1,5'),
(12, 3000,9650,14,'B','0/+1,5'),
(7, 796,9350,2,'A','0/+1,5'),
(1, 796,9650,14,'B','0/+1,5'),
(7, 796,3950,2,'C','0/+1,5');